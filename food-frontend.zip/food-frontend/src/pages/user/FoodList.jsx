import { useEffect, useState } from "react";
import { getAllFood } from "../../api/foodApi";
import { bookFood } from "../../api/orderApi";

export default function FoodList() {
  const [foods, setFoods] = useState([]);
  const [message, setMessage] = useState(""); // ✅ FIX
  const [quantities, setQuantities] = useState({});

  const username = localStorage.getItem("username");

  useEffect(() => {
    const loadFood = async () => {
      const res = await getAllFood();
      setFoods(res.data);
    };
    loadFood();
  }, []);

  // ➕ Increase quantity
  const increaseQty = (id) => {
    setQuantities((prev) => ({
      ...prev,
      [id]: (prev[id] || 1) + 1,
    }));
  };

  // ➖ Decrease quantity
  const decreaseQty = (id) => {
    setQuantities((prev) => ({
      ...prev,
      [id]: Math.max(1, (prev[id] || 1) - 1),
    }));
  };

  // 📦 Book food
  const handleBook = async (food) => {
    const qty = quantities[food.foodId] || 1;

    try {
      await bookFood(food.foodId, username, qty);
      setMessage("✅ Booking successful!");
    } catch (err) {
      console.error(err);
      setMessage("❌ Booking failed");
    }
  };

  return (
    <>
      <h2>🍽 Menu</h2>
      {message && <p>{message}</p>}

      <div className="food-grid">
        {foods.map((f) => {
          const qty = quantities[f.foodId] || 1;
          const total = qty * f.price;

          return (
            <div key={f.foodId} className="card">
              <img
                src={f.imageUrl || "/images/default-food.jpg"}
                alt={f.foodName}
              />

              <h4>{f.foodName}</h4>
              <p>Price: ₹{f.price}</p>

              {/* Quantity Controls */}
              <div className="qty-box">
                <button onClick={() => decreaseQty(f.foodId)}>-</button>
                <span>{qty}</span>
                <button onClick={() => increaseQty(f.foodId)}>+</button>
              </div>

              <p><b>Total: ₹{total}</b></p>

              <button onClick={() => handleBook(f)}>
                Book Now
              </button>
            </div>
          );
        })}
      </div>
    </>
  );
}
