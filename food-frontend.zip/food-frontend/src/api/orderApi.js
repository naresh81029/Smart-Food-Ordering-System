import axios from "axios";

const URL = "http://localhost:8081/api/orders";

// USER
export const bookFood = (foodId, username, quantity) =>
  axios.post(
    `${URL}/book/${foodId}?username=${username}&quantity=${quantity}`
  );
export const userOrders = (username) =>
  axios.get(`${URL}/user/${username}`);

export const cancelOrder = (id) =>
  axios.patch(`${URL}/cancel/${id}`);

// ✅ ADMIN (THIS WAS MISSING)
export const allOrders = () =>
  axios.get(`${URL}/admin`);
