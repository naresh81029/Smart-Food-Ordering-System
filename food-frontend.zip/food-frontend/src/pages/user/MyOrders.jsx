import { useEffect, useState, useCallback } from "react";
import { userOrders, cancelOrder } from "../../api/orderApi";

export default function MyOrders() {
  const [orders, setOrders] = useState([]);
  const [filter, setFilter] = useState("ALL");
  const username = localStorage.getItem("username");

  const loadOrders = useCallback(async () => {
    try {
      const res = await userOrders(username);
      setOrders(res.data);
    } catch (err) {
      console.error("Failed to load orders", err);
    }
  }, [username]);

  useEffect(() => {
    if (username) {
      loadOrders();
    }
  }, [username, loadOrders]);

  const handleCancel = async (id) => {
    await cancelOrder(id);
    loadOrders();
  };

  const filteredOrders = orders.filter(o => {
    if (filter === "ALL") return true;
    return o.status === filter;
  });

  return (
    <div className="container">
      <h2>📦 My Orders</h2>

      <div style={{ marginBottom: "20px" }}>
        <button onClick={() => setFilter("ALL")}>All</button>
        <button onClick={() => setFilter("BOOKED")}>Booked</button>
        <button onClick={() => setFilter("CANCELLED")}>Cancelled</button>
      </div>

      {filteredOrders.map(o => (
        <div key={o.id} className="card">
          <h4>{o.foodName}</h4>

          <p>Quantity: {o.quantity}</p>
          <p>Price: ₹{o.price}</p>

          {/* ✅ FIXED LINE */}
          <p><strong>Total:</strong> ₹{o.totalAmount}</p>

          <p>Status: {o.status}</p>

          {o.status === "BOOKED" && (
            <button className="danger" onClick={() => handleCancel(o.id)}>
              Cancel Order
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
